// Born2Win Custom — small site effects (no libraries needed)
document.documentElement.classList.add('js');

document.addEventListener('DOMContentLoaded', () => {
  // Header turns solid after you scroll past the top
  const header = document.querySelector('.site-header');
  const onScroll = () => header && header.classList.toggle('solid', window.scrollY > 40);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // Fade/slide sections in as they scroll into view
  const items = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.15 });
    items.forEach((el) => io.observe(el));
  } else {
    items.forEach((el) => el.classList.add('in'));
  }

  // Count-up numbers: <b data-count="30">0</b>
  const counters = document.querySelectorAll('[data-count]');
  const runCount = (el) => {
    const end = parseInt(el.dataset.count, 10);
    const start = performance.now();
    const dur = 1600;
    const tick = (now) => {
      const p = Math.min((now - start) / dur, 1);
      el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))) + (el.dataset.suffix || '');
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) {
    const co = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) { runCount(e.target); co.unobserve(e.target); } });
    }, { threshold: 0.5 });
    counters.forEach((c) => co.observe(c));
  }

  // Seamless marquee: duplicate the text once
  document.querySelectorAll('.marquee-track').forEach((t) => { t.innerHTML += t.innerHTML; });

  // Tap a gallery photo to view it full screen
  const box = document.querySelector('.lightbox');
  if (box) {
    const big = box.querySelector('img');
    document.querySelectorAll('.gallery button').forEach((btn) => {
      btn.addEventListener('click', () => {
        const img = btn.querySelector('img');
        big.src = img.src; big.alt = img.alt;
        box.classList.add('open');
      });
    });
    const close = () => box.classList.remove('open');
    box.addEventListener('click', close);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  }

  // Footer year
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();
});
